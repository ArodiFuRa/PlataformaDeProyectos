const express = require('express');
const http = require('http');
const path = require('path');
const api = require('./backend/api.js');

const app = express();

// Middleware para servir archivos estáticos desde la carpeta 'frontend'
app.use(express.static(path.join(__dirname, 'frontend')));

// Middleware para las rutas de la API
app.use(express.json()); // Añadir middleware para parsear JSON
app.use('/api', api);  // Usa '/api' como prefijo para las rutas API

// Ruta para el index.html
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'frontend', 'index.html'));
});

// Crear y lanzar el servidor en el puerto 3001
const server = http.createServer(app);
const port = 3001;

server.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});